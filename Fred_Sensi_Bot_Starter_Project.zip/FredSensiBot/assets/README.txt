Place your original Fred Sensi Bot icon and splash artwork in this folder when ready.
