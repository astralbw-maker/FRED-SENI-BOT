# FRED SENSI BOT — starter project

This is a runnable Expo / React Native starter for the black-and-red Fred Sensi Bot design.

## Included in this first build
- Black/red mobile interface
- Home dashboard and navigation
- Sensitivity recommendation generator (0–200)
- Device and playstyle inputs
- 2x scope recommendation view
- Mira Bot, Aim Stabilizer, Head Control guidance screens
- iPhone and Android settings recommendation screens
- Training guidance
- Save/load profiles for the current app session
- Language selector UI

## Important implementation boundaries
This starter generates recommendations only. It does not modify Free Fire, inject into the game, manipulate aim, or automatically change protected iOS/Android settings. Device detection, persistent storage, video analysis, and real native game deep links are not implemented in this starter and require additional native development.

## Run locally
1. Install Node.js.
2. In this folder run `npm install`.
3. Run `npx expo start`.
4. Use Expo Go for a preview, or configure native Android/iOS build environments for installable builds.

## Build APK / IPA
For production builds, configure EAS Build and your own Apple signing credentials/provisioning profile for iOS. An ESign certificate may be usable for signing an appropriately packaged IPA depending on certificate type, provisioning, entitlements, and device distribution method. It is not embedded automatically by this starter.
