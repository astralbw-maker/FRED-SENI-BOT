
import React, { useMemo, useState } from "react";
import {
  SafeAreaView, ScrollView, View, Text, Pressable, TextInput,
  Switch, StyleSheet, StatusBar, Alert
} from "react-native";

const RED = "#ff3048";
const BG = "#09090d";
const PANEL = "#15151d";
const MUTED = "#a2a2b2";
const DEFAULTS = { General: 185, "Red Dot": 178, "2x Scope": 172, "4x Scope": 160, "Sniper Scope": 92, "Free Look": 145 };

function makeProfile({device, style, fireSize, fingers, issue}) {
  const base = style === "Fast drag" ? 8 : style === "Balanced" ? 0 : -8;
  const fingerAdj = fingers === "4" ? 3 : fingers === "2" ? -3 : 0;
  const fireAdj = fireSize === "Large" ? -2 : fireSize === "Small" ? 2 : 0;
  const issueAdj = issue === "Overshooting" ? -10 : issue === "Body-locking" ? 5 : 0;
  const values = {};
  Object.entries(DEFAULTS).forEach(([key, value], i) => {
    const scopeAdj = i === 4 ? -Math.round(base * 0.5) : i === 5 ? Math.round(base * 0.4) : base;
    values[key] = Math.max(0, Math.min(200, value + scopeAdj + fingerAdj + fireAdj + issueAdj));
  });
  return values;
}

function Btn({ title, active, onPress }) {
  return <Pressable onPress={onPress} style={[s.btn, active && s.btnActive]}><Text style={[s.btnText, active && {color:"#fff"}]}>{title}</Text></Pressable>;
}
function Card({ title, children, right }) {
  return <View style={s.card}><View style={s.cardHead}><Text style={s.cardTitle}>{title}</Text>{right}</View>{children}</View>;
}
function Label({ children }) { return <Text style={s.label}>{children}</Text>; }

export default function App() {
  const [tab, setTab] = useState("Home");
  const [device, setDevice] = useState("iPhone 13 mini");
  const [style, setStyle] = useState("Balanced");
  const [fireSize, setFireSize] = useState("Large");
  const [fingers, setFingers] = useState("3");
  const [issue, setIssue] = useState("Inconsistent");
  const [profileName, setProfileName] = useState("My profile");
  const [generated, setGenerated] = useState(DEFAULTS);
  const [saved, setSaved] = useState([]);
  const [language, setLanguage] = useState("English");
  const [tips, setTips] = useState(true);

  const tabs = ["Home","Sensi Bot","Mira Bot","2x Scope","Aim Stabilizer","Head Control","iPhone Settings","Android Settings","Training","Profiles"];
  const generate = () => {
    const values = makeProfile({device, style, fireSize, fingers, issue});
    setGenerated(values);
    Alert.alert("Sensitivity generated", "Your recommendations have been updated. Test them in the game's training area and adjust gradually.");
  };
  const save = () => {
    setSaved(old => [...old, {name: profileName || `Profile ${old.length+1}`, device, values: generated}]);
    Alert.alert("Saved", "Your profile has been saved for this session.");
  };

  const Header = () => <View style={s.header}>
    <View><Text style={s.brand}>FRED <Text style={{color:RED}}>SENSI BOT</Text></Text><Text style={s.tag}>PRECISION • CALIBRATION • CONTROL</Text></View>
    <View style={s.logo}><Text style={s.logoText}>F</Text></View>
  </View>;

  const SensitivityRows = ({only2x=false}) => {
    const entries = Object.entries(generated).filter(([k]) => !only2x || k === "2x Scope");
    return <View>{entries.map(([k,v]) => <View style={s.valueRow} key={k}><Text style={s.valueName}>{k}</Text><Text style={s.value}>{v}<Text style={s.outOf}> / 200</Text></Text></View>)}</View>;
  };

  const Generator = () => <View>
    <Card title="DEVICE & PLAYSTYLE">
      <Label>Device model</Label><TextInput value={device} onChangeText={setDevice} placeholder="Enter your device" placeholderTextColor={MUTED} style={s.input}/>
      <Label>Gameplay style</Label><View style={s.wrap}>{["Balanced","Fast drag","Controlled"].map(x=><Btn key={x} title={x} active={style===x} onPress={()=>setStyle(x)}/>)}</View>
      <Label>Number of fingers</Label><View style={s.wrap}>{["2","3","4"].map(x=><Btn key={x} title={x} active={fingers===x} onPress={()=>setFingers(x)}/>)}</View>
      <Label>Fire button size</Label><View style={s.wrap}>{["Small","Medium","Large"].map(x=><Btn key={x} title={x} active={fireSize===x} onPress={()=>setFireSize(x)}/>)}</View>
      <Label>Main aim issue</Label><View style={s.wrap}>{["Inconsistent","Overshooting","Body-locking"].map(x=><Btn key={x} title={x} active={issue===x} onPress={()=>setIssue(x)}/>)}</View>
      <Pressable style={s.primary} onPress={generate}><Text style={s.primaryText}>GENERATE SENSITIVITY</Text></Pressable>
    </Card>
    <Card title="GENERATED SENSITIVITY"><SensitivityRows/><Pressable style={s.secondary} onPress={save}><Text style={s.secondaryText}>SAVE PROFILE</Text></Pressable></Card>
  </View>;

  const recommendations = [
    ["AssistiveTouch","Use only if it improves accessibility or control comfort."],
    ["Pointer Control","Configure only when using a supported pointer device."],
    ["Gliding Cursor","Choose a mode that feels predictable and controllable."],
    ["Movement Tolerance","Start with the default and adjust for accidental movement."],
    ["Auto Scanning Time","Use a comfortable interval; this is an accessibility setting."],
    ["Loops","Set according to your Switch Control workflow."],
    ["Move Repeat","Leave off unless your accessibility workflow needs it."],
    ["Hold Duration","Use the shortest comfortable duration for your workflow."],
    ["Ignore Repeat","Adjust only if repeated inputs are a problem."],
    ["Tracking Sensitivity","Tune gradually for pointer comfort."],
    ["Dwell Control","Enable only if you intentionally use dwell selection."],
    ["Mouse Keys","Use only with a compatible keyboard workflow."]
  ];

  const SimpleTool = ({title, desc, bullets=[]}) => <Card title={title}>
    <Text style={s.body}>{desc}</Text>
    {bullets.map((b,i)=><View key={i} style={s.bulletRow}><Text style={s.bullet}>•</Text><Text style={s.body}>{b}</Text></View>)}
    <Text style={s.note}>This tool provides guidance and analysis. It does not modify Free Fire, inject code, or control the game's aiming system.</Text>
  </Card>;

  const content = () => {
    if (tab==="Home") return <>
      <View style={s.hero}><Text style={s.heroEyebrow}>WELCOME TO</Text><Text style={s.heroTitle}>FRED SENSI{"\n"}<Text style={{color:RED}}>BOT</Text></Text><Text style={s.heroDesc}>Your personal Free Fire sensitivity workspace.</Text><Pressable style={s.primary} onPress={()=>setTab("Sensi Bot")}><Text style={s.primaryText}>OPEN SENSI GENERATOR</Text></Pressable></View>
      <View style={s.grid}>{[["Sensi Bot","Generate profiles"],["Mira Bot","Aim guidance"],["2x Scope","Scope calibration"],["Aim Stabilizer","Consistency tips"],["Head Control","Crosshair guidance"],["Training","Practice routines"]].map(([a,b])=><Pressable key={a} onPress={()=>setTab(a==="Training"?"Training":a)} style={s.tile}><Text style={s.tileTitle}>{a}</Text><Text style={s.tileDesc}>{b}</Text><Text style={s.tileArrow}>↗</Text></Pressable>)}</View>
      <Card title="ACTIVE DEVICE"><Text style={s.body}>{device}</Text><Text style={s.note}>Device identification is editable; automatic hardware detection depends on the final native build.</Text></Card>
    </>;
    if (tab==="Sensi Bot") return <Generator/>;
    if (tab==="2x Scope") return <><SimpleTool title="2X SCOPE CALIBRATION" desc="Generate and review a dedicated 2x scope recommendation." bullets={["Use the generated 2x value as a starting point.","Test in a consistent training environment.","Change one setting at a time."]}/><Card title="YOUR 2X RECOMMENDATION"><SensitivityRows only2x/></Card><Pressable style={s.primary} onPress={generate}><Text style={s.primaryText}>RECALCULATE</Text></Pressable></>;
    if (tab==="Mira Bot") return <SimpleTool title="MIRA BOT" desc="Review your aim consistency and get practical sensitivity guidance." bullets={["Compare repeated training attempts.","Watch for overshooting or body-level tracking.","Upload-based video analysis can be added in a later build."]}/>;
    if (tab==="Aim Stabilizer") return <SimpleTool title="AIM STABILIZER" desc="A calibration guide for steadier, more repeatable input." bullets={["Keep one baseline profile.","Adjust sensitivity in small increments.","Avoid changing several settings at once."]}/>;
    if (tab==="Head Control") return <SimpleTool title="HEAD CONTROL" desc="Crosshair placement and sensitivity guidance for consistent practice." bullets={["Use a comfortable crosshair starting position.","Review aim consistency across several attempts.","Save separate profiles for different weapons if useful."]}/>;
    if (tab==="iPhone Settings" || tab==="Android Settings") return <Card title={tab.toUpperCase()}><Text style={s.body}>Recommendations only. Operating-system accessibility and pointer settings may need to be changed manually.</Text>{(tab==="iPhone Settings"?recommendations:[["Display settings","Use comfortable display settings supported by your device."],["Touch settings","Review touch and accessibility options in Android Settings."],["DPI","Do not change density unless you understand the device-specific effects."],["Gaming performance","Close unnecessary background apps and keep the device updated."]]).map(([name,desc])=><View key={name} style={s.setting}><Text style={s.settingName}>{name}</Text><Text style={s.note}>{desc}</Text></View>)}</Card>;
    if (tab==="Training") return <SimpleTool title="TRAINING MODE" desc="A safe practice hub. The app does not inject into, modify, or automate Free Fire." bullets={["Warm up with a consistent sensitivity profile.","Practise controlled swipes and crosshair placement.","Record results and adjust one value at a time.","Use the official game app to enter its training area."]}/>;
    if (tab==="Profiles") return <><Card title="SAVE CURRENT PROFILE"><TextInput value={profileName} onChangeText={setProfileName} style={s.input} placeholder="Profile name" placeholderTextColor={MUTED}/><Pressable style={s.primary} onPress={save}><Text style={s.primaryText}>SAVE CURRENT SETTINGS</Text></Pressable></Card><Card title="SAVED PROFILES">{saved.length===0?<Text style={s.note}>No profiles saved in this session yet.</Text>:saved.map((p,i)=><View key={i} style={s.setting}><Text style={s.settingName}>{p.name}</Text><Text style={s.note}>{p.device} • General {p.values.General}</Text><Pressable onPress={()=>{setGenerated(p.values);setDevice(p.device);Alert.alert("Loaded",p.name+" loaded.");}}><Text style={{color:RED,marginTop:8,fontWeight:"800"}}>LOAD PROFILE</Text></Pressable></View>)}</Card></>;
    return <Card title="SETTINGS"><Text style={s.body}>Language</Text><View style={s.wrap}>{["English","Português (BR)"].map(x=><Btn key={x} title={x} active={language===x} onPress={()=>setLanguage(x)}/>)}</View><View style={s.setting}><Text style={s.settingName}>Show guidance tips</Text><Switch value={tips} onValueChange={setTips} trackColor={{true:RED,false:"#444"}}/></View><Text style={s.note}>FRED SENSI BOT • Original independent project concept.</Text></Card>;
  };

  return <SafeAreaView style={s.safe}><StatusBar barStyle="light-content" backgroundColor={BG}/><Header/>
    <ScrollView contentContainerStyle={s.scroll} showsVerticalScrollIndicator={false}>
      <Text style={s.section}>{tab.toUpperCase()}</Text>{content()}
      <Text style={s.footer}>FRED SENSI BOT • BUILD 0.1</Text>
    </ScrollView>
    <ScrollView horizontal showsHorizontalScrollIndicator={false} style={s.nav} contentContainerStyle={s.navInner}>
      {tabs.map(t=><Pressable key={t} onPress={()=>setTab(t)} style={[s.navItem,tab===t&&s.navSelected]}><Text style={[s.navText,tab===t&&{color:"#fff"}]}>{t}</Text></Pressable>)}
    </ScrollView>
  </SafeAreaView>;
}

const s=StyleSheet.create({
 safe:{flex:1,backgroundColor:BG}, header:{paddingHorizontal:20,paddingTop:10,paddingBottom:14,flexDirection:"row",justifyContent:"space-between",alignItems:"center",borderBottomWidth:1,borderBottomColor:"#24242d"},
 brand:{fontSize:20,fontWeight:"900",color:"#fff",letterSpacing:1},tag:{fontSize:8,color:MUTED,letterSpacing:1.5,marginTop:4},logo:{width:40,height:40,borderRadius:12,backgroundColor:RED,alignItems:"center",justifyContent:"center"},logoText:{color:"#fff",fontWeight:"900",fontSize:24},
 scroll:{padding:16,paddingBottom:24},section:{color:RED,fontSize:11,fontWeight:"900",letterSpacing:2,marginBottom:14},
 hero:{backgroundColor:PANEL,borderRadius:20,padding:20,borderWidth:1,borderColor:"#30202a",marginBottom:14},heroEyebrow:{color:MUTED,fontSize:10,letterSpacing:2,fontWeight:"800"},heroTitle:{fontSize:38,lineHeight:40,color:"#fff",fontWeight:"900",marginTop:8},heroDesc:{color:MUTED,marginTop:10,marginBottom:18},
 grid:{flexDirection:"row",flexWrap:"wrap",gap:10,marginBottom:14},tile:{width:"48%",minHeight:104,backgroundColor:PANEL,borderRadius:15,padding:14,borderWidth:1,borderColor:"#292933"},tileTitle:{color:"#fff",fontWeight:"900",fontSize:15},tileDesc:{color:MUTED,fontSize:11,marginTop:7},tileArrow:{color:RED,fontSize:18,position:"absolute",right:12,bottom:10},
 card:{backgroundColor:PANEL,borderRadius:16,padding:16,borderWidth:1,borderColor:"#292933",marginBottom:13},cardHead:{flexDirection:"row",justifyContent:"space-between",alignItems:"center",marginBottom:13},cardTitle:{color:"#fff",fontSize:12,fontWeight:"900",letterSpacing:1.2},
 label:{color:MUTED,fontSize:11,fontWeight:"700",marginTop:12,marginBottom:7},input:{backgroundColor:"#0d0d13",borderWidth:1,borderColor:"#343440",borderRadius:10,paddingHorizontal:12,paddingVertical:11,color:"#fff"},
 wrap:{flexDirection:"row",flexWrap:"wrap",gap:7},btn:{paddingHorizontal:12,paddingVertical:9,borderRadius:9,borderWidth:1,borderColor:"#393944",backgroundColor:"#101017"},btnActive:{backgroundColor:RED,borderColor:RED},btnText:{color:MUTED,fontSize:11,fontWeight:"800"},
 primary:{backgroundColor:RED,padding:14,borderRadius:11,alignItems:"center",marginTop:16},primaryText:{color:"#fff",fontSize:11,fontWeight:"900",letterSpacing:1},
 secondary:{borderWidth:1,borderColor:RED,padding:12,borderRadius:10,alignItems:"center",marginTop:12},secondaryText:{color:RED,fontWeight:"900",fontSize:11},
 valueRow:{flexDirection:"row",justifyContent:"space-between",paddingVertical:10,borderBottomWidth:1,borderBottomColor:"#292933"},valueName:{color:"#ddd",fontSize:13},value:{color:"#fff",fontSize:15,fontWeight:"900"},outOf:{color:MUTED,fontSize:10,fontWeight:"500"},
 body:{color:"#dedee6",fontSize:13,lineHeight:20},note:{color:MUTED,fontSize:10,lineHeight:16,marginTop:5},bulletRow:{flexDirection:"row",gap:8,marginTop:9},bullet:{color:RED,fontSize:17},setting:{paddingVertical:12,borderBottomWidth:1,borderBottomColor:"#292933"},settingName:{color:"#fff",fontSize:13,fontWeight:"800"},footer:{textAlign:"center",color:"#626271",fontSize:9,letterSpacing:1,marginVertical:18},
 nav:{maxHeight:58,borderTopWidth:1,borderTopColor:"#292933",backgroundColor:"#101016"},navInner:{alignItems:"center",paddingHorizontal:8,gap:6},navItem:{paddingHorizontal:12,paddingVertical:10,borderRadius:9},navSelected:{backgroundColor:RED},navText:{color:MUTED,fontSize:10,fontWeight:"800"}
});
